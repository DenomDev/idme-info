export interface Specialization {
  id: string;
  name: string;
}
