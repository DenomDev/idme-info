export interface Service {
  id: string;
  name: string;
}
